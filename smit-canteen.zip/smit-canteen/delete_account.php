
<br>

<h2 style="text-align:center; ">Do you really want to DELETE your account?</h2>

<form action="" method="post">

<br><center>
<input type="submit" name="yes" value="Yes I want" /> 
<input type="submit" name="no" value="no" />
<style type="text/css">
       body{
       background-image: url("images/backf.jpg");
       background-size: 100%;

    }

</style>
</center>
</form>

<?php 
include("includes/db.php"); 
session_start();
	$user = $_SESSION['customer_email']; 
	
	if(isset($_POST['yes'])){
	
	$delete_customer = "delete from customers where customer_prn='$user'";
	
	$run_customer = mysqli_query($con,$delete_customer); 
	
	echo "<script>alert('We are really sorry, your account has been deleted!')</script>";
	echo "<script>window.open('../index.php','_self')</script>";
	}
	if(isset($_POST['no'])){
	
	echo "<script>alert('oh! do not joke again!')</script>";
	echo "<script>window.open('my_account.php','_self')</script>";
	
	}
	


?>