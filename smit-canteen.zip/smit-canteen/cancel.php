<?php
session_start();
include("includes/db.php");
$user=$_SESSION['customer_email'];
$sum=$_POST['hid'];
$query3="SELECT * from customers WHERE customer_prn='$user'";

					$runQuery4=mysqli_query($con,$query3);
						while($row=mysqli_fetch_assoc($runQuery4))
                                        {
						$amount=$row['amount'];
					}
$i=0;
				if($sum > "0")
                                {
					
					$query3="SELECT * from orders_admin WHERE customer_prn='$user'";
					$runQuery4=mysqli_query($con,$query3);
					while($row=mysqli_fetch_assoc($runQuery4))
                                        {
						$id=$row['p_id'];
						$productName=$row['p_name'];
						$price=$row['p_price'];
						$user=$row['customer_prn'];
                                                $status=$row['order_status'];
                                                if($status=='Complete')
						{
                                                $i++;
						}
					}
                                         if($i>"0")
					{
					        echo "<script>alert('cannot be cancelled as one or more items are ready')</script>";
					        echo "<script>window.open('index.php');</script>";
					        echo"<script>close();</script>";
					}
					else if($i=="0")
					{
						$query3="SELECT * from orders_admin WHERE customer_prn='$user'";
					        $runQuery4=mysqli_query($con,$query3);
					        while($row=mysqli_fetch_assoc($runQuery4))
                                                {
                                                $id=$row['p_id'];
						$productName=$row['p_name'];
						$price=$row['p_price'];
						$user=$row['customer_prn'];
						$query1="DELETE FROM orders_admin WHERE p_id='$id' AND p_name='$productName' AND p_price='$price' AND  customer_prn='$user'";
						$runQuery1=mysqli_query($con,$query1);
                                                }
					$query3="UPDATE customers SET amount=amount+'$sum' WHERE customer_prn='$user'";
					$runQuery3=mysqli_query($con,$query3);
                                                echo "<script>alert('cancelled')</script>";
					        echo "<script>window.open('index.php');</script>";
					        echo"<script>close();</script>";
					}
					$query="TRUNCATE table orders";
					$run_t = mysqli_query($con, $query);
				  }
                                        else
                                        {
                                             echo "<script>alert('order not yet placed')</script>";
				              echo "<script>window.open('full_menu.php');</script>";
					      echo"<script>close();</script>";
				         }
					?>				

}