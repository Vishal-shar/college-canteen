<?php 
	include("includes/db.php"); 

	if(isset($_GET['order_status'])){

	$order_id = $_GET['order_status']; 
	
	$get_order = "select * from orders_admin where order_id='$order_id'";

	$run_order = mysqli_query($con, $get_order); 
	
	$row_order = mysqli_fetch_array($run_order); 
	
	$order_id = $row_order['order_id'];
	$order_status = $row_order['order_status'];
}


?>
<form action="" method="post" style="padding:80px;">

<b>Update Order Status:</b>
<select name="new_order_status">
<option>Order Status</option>
<option>Incomplete</option>
<option>Complete</option>
<input type="submit" name="update_order_status" value="Update Order Status" /> 

</form>

<?php 


	if(isset($_POST['update_order_status'])){
	
	$update_id = $order_id;
	
	$new_order_status = $_POST['new_order_status'];
	
	$update_order_status = "update orders_admin set order_status='$new_order_status' where order_id='$update_id'";

	$run_cat = mysqli_query($con, $update_order_status); 
	
	if($run_order){
	
	echo "<script>alert(' Order status has been updated!')</script>";
	echo "<script>window.open('index.php?view_orders','_self')</script>";
	}
	}

?>