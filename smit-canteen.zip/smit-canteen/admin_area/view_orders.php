<table width="1150" align="center" bgcolor="grey" style="color: white"> 

	
	<tr align="center">
		<td colspan="6"><h2>All orders</h2></td>
	</tr>
	
	<tr align="center" bgcolor="white" style="color: black">
		<th>S.N</th>
		<th>Food Item</th>
		<th>Price</th>
		<th>Registration Number</th>
                <th>Order Status</th>
                <th>Delete</th>
	</tr>
	<?php 
	include("includes/db.php");
	
	$get_order = "select * from orders_admin";
	
	$run_order = mysqli_query($con, $get_order); 
	
	$i = 0;
	
	while ($row_order=mysqli_fetch_assoc($run_order)){
		
		$order_id = $row_order['order_id'];
		$pro_id = $row_order['p_id'];
		$pro_name=$row_order['p_name'];
		$pro_price = $row_order['p_price'];
		$c_prn = $row_order['customer_prn'];
		$i++;
		
		
	?>
	
	<tr align="center">
		<td><?php echo $i;?></td>
		<td><?php echo$pro_name;?></td>
		<td><?php echo$pro_price;?></td>
		<td><?php echo$c_prn;?></td>
                <td><a href="index.php?order_status=<?php echo $order_id;?>">Order Status</a></td>
                <td><a href="delete_order.php?delete_order=<?php echo $order_id;?>">Delete</a></td>

	
	</tr>
<?php 

	 } ?>
</table>