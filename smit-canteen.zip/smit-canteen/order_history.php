<!DOCTYPE html>
<html>
<head>
	<?php
	session_start();
	include("includes/db.php");
		$total=0;
		if(!isset($_SESSION['customer_email'])){
		header("location: customer_login.php");
		}
									$user=$_SESSION['customer_email'];
							$query4="SELECT sum(p_price) FROM orders WHERE customer_prn='$user'";
							$runQuery4=mysqli_query($con,$query4);
								while($row=mysqli_fetch_assoc($runQuery4)){
								$sum=$row['sum(p_price)'];
		}
	?>
	<title>Order History</title>
	<meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	   <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="shortcut icon" href="themes/assets/ico/favicon.ico">
      <link href="themes/assets/css/carousel.css" rel="stylesheet">
      <style type="text/css">
       body{
       background-image: url("images/backf.jpg");
       background-size: 100%;

    }
    
  </style>
</head>


<body>

	<div class="navbar-wrapper" >
      <div class="navbar navbar-inverse navbar-static-top " role="navigation">
        <h2 align="center" style="color: cyan"><font face=Arial black><b>ORDER HISTORY</font></b></h2> 
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse ">
            <span class="sr-only">Toggle navigation</span>
	    
          </button>
                  <a class="navbar-brand" href="index.html"></a>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li><a href="index.php">Home</a></li>
              <li><a href="about_us.php">About Us</a></li>
              <li><a href="full_menu.php">Full Menu</a></li>
	      <li><a href="order_history.php">Order history</a></li>
              <li><a href="logout.php">Logout</a></li>
            </ul>
          </div>
        </div>
      </div>



      <table cellpadding="20" cellspacing="20" align="center" style="color:black">
      	<tr style="margin-left: 2em;" bgcolor="white"  cellpadding="10">
	
	
      		<th>&ensp;  No.</th>
      		<th>&nbsp;  Name </th>
            <th>&nbsp;  Price </th>
      		
      	</tr>
			<?php

				$i=0;
				$query="SELECT * FROM orders WHERE customer_prn='$user'" ;

				$runQuery=mysqli_query($con,$query);


				while($row=mysqli_fetch_assoc($runQuery)){
					$productName=$row['p_name'];

					$price=$row['p_price'];
                                
        				$total+=$price;
                        
				$i++;
				
				echo '

					<tr style="margin-left: 2em;" cellspacing="5">
						<td>'.$i.'</td>
						<td>'.$productName.'</td>
						<td>'.$price.'</td>
						                 
                                                </tr>



					';

					
					
				}
				echo'
				<tr style=margin-lefy:2em;" cellspacing="5">
				<td><b>Total</b></td>
				<td></td>
				<td><b>'.$total.'</b></td>  
				</tr>
				';

			?>
			</table><br><br>
		
</body>
</html>