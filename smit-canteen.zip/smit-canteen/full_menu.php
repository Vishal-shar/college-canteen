<!DOCTYPE html>
<html>
<head>
	<?php
	session_start();
	include("includes/db.php");
		if(!isset($_SESSION['customer_email'])){
		header("location: customer_login.php");
		}
									$user=$_SESSION['customer_email'];
							$query4="SELECT sum(p_price) FROM orders WHERE customer_prn='$user'";
							$runQuery4=mysqli_query($con,$query4);
								while($row=mysqli_fetch_assoc($runQuery4)){
								$sum=$row['sum(p_price)'];
								
		}
	?>
	<title>Full Menu</title>
	<meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	   <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="shortcut icon" href="themes/assets/ico/favicon.ico">
      <link href="themes/assets/css/carousel.css" rel="stylesheet">
      <style type="text/css">
       body{
       background-image: url("images/backf.jpg");
       background-size: 100%;

    }

    
    
  </style>
</head>


<body>

	<div class="navbar-wrapper" >
      <div class="navbar navbar-inverse navbar-static-top " role="navigation">
        <h2 align="center" style="color: cyan"><font face=Arial black><b>FULL MENU</font></b></h2> 
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse ">
            <span class="sr-only">Toggle navigation</span>
          </button>
                  <a class="navbar-brand" href="index.html"></a>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li><a href="index.php">Home</a></li>
              <li><a href="about_us.php">About Us</a></li>
              <li><a href="full_menu.php">Full Menu</a></li>
			  <li><a href="order_history.php">Order History</a></li>
              <li><a href="logout.php">Logout</a></li>
		 <?php if(isset($_SESSION['customer_email'])){
                $q="SELECT customer_name, amount FROM customers WHERE customer_prn='$_SESSION[customer_email]'";
                $runQuery4=mysqli_query($con,$q);
                $row=mysqli_fetch_assoc($runQuery4);
                echo "<li><a>".$row['customer_name']."</a></li>";
                echo "<li><a>".$row['amount']."</a></li>";
              }?>
            </ul>
          </div>
        </div>
      </div>
      <table cellpadding="20" cellspacing="20" align="center" style="color:black">
      	<tr style="margin-left: 2em;">
      		<th> No. </th>
      		<th>&ensp; &ensp; &ensp; Name </th>
      		<th>&ensp; &ensp; &ensp; Price </th>
			<th>&ensp;  Quantity</th>
<!--
		  <td>Quantity</td> 
		  <td class="vote">5</td>
          
	                              <td>
	                               <a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                                <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
									</td>
									      <td>
											  <br/>
											  <br/>
											  <br/>
											  <br/>
											  <br/>
											  <br/>
											  
			<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                 <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
											  
			  </td>
			  </td>		
			<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
			     </td>
                            </tr>
                            <tr>
			<td>
			 <a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                 <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
									</td>
                           </tr>
                           <tr>
			<td>
			<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
									</td>
                              </tr>
                              <tr>
			     <td>
			<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
									</td>
                               </tr>
                               <tr>
				<td>
			<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	                <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
									</td>
                          </tr>
                          <tr>
			<td>
			<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	              <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
		        </td>
                         </tr>
                         <tr>
			<td>
		<a href="full_menu.php" class="btn btn-lg btn-primary addVote">+</a>
	           <a href="full_menu.php" class="btn btn-lg btn-primary subVote">-</a>
	              </td>
                                        
                                  
			                         	  
		</tr>								
			  
      	</tr> -->
			<?php

				$i=0;
				$query="SELECT *FROM products";

				$runQuery=mysqli_query($con,$query);


				while($row=mysqli_fetch_assoc($runQuery)){
					$productName=$row['product_title'];

					$price=$row['product_price'];
					$id=$row['product_id'];
					$i++;
					
					
#<td align="center"><a href="full_menu.php?product_id='.$id.'"><button type="button" name="call" class="btn btn-primary">'.$price.'</button></a></td>-->

				echo '

					<tr style="margin-left: 2em;" >
						<td>'.$i.'</td>
						<td>&ensp;&ensp;'.$productName.'</td>
						<td> &ensp; &ensp; &ensp;'.$price.'</td>
<td><a href="full_menu.php?product_id='.$id.'"><button type="button" name="call" class="btn btn-primary">+</button></a></td>
<td><a href="full_menu.php?product_id='.$id.'"><button type="button" name="call" class="btn btn-primary">-</button></a></td>

					</tr>



					';


				}
			?>  
			 
	                             
	                                                            	  
			</table><br><br>
			<?php
				if(isset($_GET['product_id'])){


						$id=$_GET['product_id'];

						$query="SELECT *FROM products WHERE product_id=".$id;
						$runQuery=mysqli_query($con,$query);
						while($row=mysqli_fetch_assoc($runQuery)){
							$productName=$row['product_title'];
							$price=$row['product_price'];

			        $query1="INSERT INTO orders (p_id,p_name,p_price,customer_prn) VALUES ('$id','$productName','$price','$user')";
							$runQuery1=mysqli_query($con,$query1);
								
						}

				}
    



						
				
							?>
						<center><span><p style="color:black">Current Cart amount : <?php 
							      
							  
						$query3="SELECT (p_price) FROM orders WHERE customer_prn='$user'";
						$runQuery3=mysqli_query($con,$query3);
							while($nrow=mysqli_fetch_assoc($runQuery3)){
								if(isset($nrow['sum(p_price)'] ))
									$sum=$nrow['sum(p_price)'];
							}
						if($sum!=0) echo $sum;

			      
				  
?></p>

			  	  </span>
					<div class="btn-group">	
				<form method="POST" action="formpro.php">
					<input type="submit" class="btn btn-success" value="FINALIZE ORDER" name="sub">
					<input type="hidden" name="hid" value= <?php echo $sum;?> >   					                                        </form>

                                         </div>
                                        <div class="btn-group">
                                   <form method="POST" action="status.php">
					<input type="submit" class="btn btn-success"  value="ORDER STATUS" name="sub">
					<input type="hidden" name="hid" value= <?php echo $sum;?> >	
					</form> 
                                         </div>
					<div class="btn-group">	  
                                 <form method="POST" action="cancel.php">
					<input type="submit" class="btn btn-success"  value="CANCEL ORDER" name="sub">
					<input type="hidden" name="hid" value= <?php echo $sum;?> >
					</form></center>
			    </div>
		   







</body>
</html>