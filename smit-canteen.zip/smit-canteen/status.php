<?php
session_start();
include("includes/db.php");
$user=$_SESSION['customer_email'];
$sum=$_POST['hid'];
$query3="SELECT * from customers WHERE customer_prn='$user'";

					$runQuery4=mysqli_query($con,$query3);
						while($row=mysqli_fetch_assoc($runQuery4)){
						$amount=$row['amount'];
					                                                  }
					if($sum > "0")
                                        {

                                        $query3="SELECT * from orders_admin WHERE customer_prn='$user'";
					$runQuery4=mysqli_query($con,$query3);
					while($row=mysqli_fetch_assoc($runQuery4))
                                        {
						$id=$row['p_id'];
						$productName=$row['p_name'];
						$price=$row['p_price'];
						$user=$row['customer_prn'];
                                                $status=$row['order_status'];
                                        }
if($status =="Incomplete")
{
echo "<script>alert('Order is being prepared')</script>";
					echo "<script>window.open('full_menu.php');</script>";
					echo"<script>close();</script>";
}
else
                                       {
echo "<script>alert('Order is ready,Please Pick up from canteen')</script>";
					echo "<script>window.open('index.php');</script>";
					echo"<script>close();</script>";
				
					}
					
				}
                                else
                                {
                                echo "<script>alert('order not yet placed')</script>";
				echo "<script>window.open('full_menu.php');</script>";
					echo"<script>close();</script>";
				}
                                        
					?>				}
					