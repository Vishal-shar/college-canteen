<h2 style="text-align:center;">Reset Your Password</h2>
<form method="post"> 
	
	<table align="center" width="600">
	<tr>
	<td align="right"><b>Enter PRN NO.</b></td>
	<td><input type="customer PRN" name="customer_prn" required></td>
	</tr>
	
	<tr>
	<td align="right"><b>Enter New Password:</b></td>
	<td><input type="password" name="new_pass" required></td>
	</tr>
	
	<tr>
	<td align="right"><b>Enter New Password Again:</b></td>
	<td><input type="password" name="new_pass_again" required></td>
	</tr>
	
	<tr align="center">
	<td colspan="3"><input type="submit" name="update_pass" value="update Password"/></td>
	</tr>
	
	</table>
<style type="text/css">
       body{
       background-image: url("images/backf.jpg");
background-size: 100%;
}
</style>

</form>
<div>
<?php 
include("includes/db.php"); 
	if(isset($_POST['update_pass'])){
		$customer_prn=$_POST["customer_prn"]; 
		$new_pass=$_POST["new_pass"]; 
		$new_again=$_POST["new_pass_again"]; 
		if($new_pass!=$new_again){
		
			echo "<script>alert('New password do not match!')</script>";
			exit();
		}
		
		$sel_pass = "select * from customers where customer_prn=".$customer_prn;
		$run_pass = mysqli_query($con, $sel_pass); 
		
		$check_pass = mysqli_num_rows($run_pass); 
		
		if($check_pass==0){
			echo "<script>alert('your current password is wrong!')</script>";
		exit();
		}
		else {
		
		$update_pass = "update customers set customer_pass=".$new_pass." where customer_prn=".$customer_prn;
		$run_update = mysqli_query($con, $update_pass); 
		
		echo "<script>alert('Your password was updated succesfully!')</script>";
		echo "<script>window.open('my_account.php','_self')</script>";
		}
	
	}

?>
</div>