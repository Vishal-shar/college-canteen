<!DOCTYPE html>
<html>
<head>
  <title>About US</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    <style type="text/css">
       body{
       background-image:url("images/back.jpg");
       background-size: 100%;
       background-repeat: no-repeat;

    }
    
  </style>
</head>
<body>
  <h1 align="center" style="color: blue">The Team Members and Guide</h1>

  
<br>
<br>
<br>
<br>
<br>

  <div class="w3-row-padding w3-padding-16 w3-center" style="color:black">
    <div class="w3-quarter">


      <img class="img-rounded " src="images/kartik.png" alt="Shwetabh" style="width: 250px;height: 250px">
      <h3>Shwetabh Singh</h3>
<marquee>
      <p>Front end and Back end Developer </p>
      <p>Final year student of smit project group 2</p>
  </marquee>    
    </div>
    <div class="w3-quarter">
      <img class="img-rounded " src="images/kalpu.png" alt="Vishal Sharma" style="width: 250px;height: 250px">
      <h3>Vishal Sharma</h3>
<marquee>
      <p>Front end and Back end Developer</p>
      <p>Final year student of smit project group 2</p>
	</marquee>
    </div>
    <div class="w3-quarter">
      <img class="img-rounded " src="images/kp.png" alt="Abhirup" style="width: 250px;height: 250px">
      <h3>Abhirup</h3>
<marquee>
      <p>Front end and Back end Developer</p>
      <p>Final year student of smit project group 2</p>
</marquee>
    </div>
    <div class="w3-quarter">
      <img class="img-rounded " src="images/ajit.png" alt="Diepndra Gurung" style="width: 250px;height: 250px">
      <h3>Dipendra Gurung</h3>
<marquee>
      <p>Project guide</p>
      <p>Teacher of smit as well our guide for project group 2</p>
</marequee>
    </div>


<p style="color:black">&copy; 2022 SMIT;</p>
<a href="customer_login.php">Back to Home </a>
  

</body>
</html>


